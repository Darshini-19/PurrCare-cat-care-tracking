# PurrCare — Cat Care Tracking System

Full-stack app: **Express + MongoDB** backend and **React (Vite)** frontend. Each major feature lives on its own page.

## Prerequisites

- [Node.js](https://nodejs.org/) 18+
- [MongoDB](https://www.mongodb.com/) running locally, or a cloud URI

## Project layout

```
PurrCare/
├── backend/          # API (server.js, models/, routes/)
├── frontend/         # React app (pages per module)
└── README.md
```

## Setup

### 1. Backend

```bash
cd PurrCare/backend
copy .env.example .env
npm install
npm run dev
```

Default API: `http://127.0.0.1:5000`. Set `MONGODB_URI` in `.env` if your database is not local.

**Auth:** set `JWT_SECRET` in `.env` for signing login tokens (use a long random string in production).

**Forgot password:** set `SUPPORT_EMAIL` in `.env` to the address that should receive reset requests. The app opens the user’s mail client with a pre-filled `mailto:` to that address (no automated email is sent from the server).

**Optional AI chatbot:** add `OPENAI_API_KEY` to `.env`. Without it, the chat endpoint returns built-in guidance only.

After `npm install` in `backend`, new dependencies include `bcryptjs` and `jsonwebtoken`.

### 2. Frontend

```bash
cd PurrCare/frontend
npm install
npm run dev
```

Open the URL Vite prints (usually `http://127.0.0.1:5173`). The dev server proxies `/api` to port 5000.

## Pages (frontend)

| Route    | Module        |
|----------|---------------|
| `/`      | Home — landing (guest) or dashboard (signed in) |
| `/login` | Log in (username + 6-digit password) |
| `/signup` | Sign up (full name, email, phone, username, password) |
| `/forgot-password` | Forgot password — opens email draft to `SUPPORT_EMAIL` |
| `/cats`  | Cat profiles |
| `/care`  | Care tracker (feeding, water, litter) |
| `/vet`   | Vet tracker |
| `/food`  | Food & care guide |
| `/chat`  | Behavior chatbot |

## API overview

- `POST /api/auth/signup` — `{ fullName, email, phone, username, password }` (password: exactly **6 digits**; full name must be unique and matches cat “owner name”; username is used to log in)
- `POST /api/auth/login` — `{ username, password }` → `{ token, user }`
- `GET /api/auth/support-config` — `{ supportEmail }` for the forgot-password flow
- `POST /api/auth/forgot-password` — `{ username }` → `{ mailtoUrl }` opens a draft to `SUPPORT_EMAIL` with account details
- `GET /api/auth/me` — requires `Authorization: Bearer <token>`

Protected (same header): cats, logs, dashboard.

- `GET/POST /api/cats`, `GET/PUT/DELETE /api/cats/:id`
- `GET/POST /api/cats/:catId/logs` (query `?category=feeding|water|litter|vet`)
- `DELETE /api/logs/:logId`
- `GET /api/dashboard`
- `POST /api/chat` — body: `{ "messages": [{ "role": "user"|"assistant", "content": "..." }] }`
- `GET /api/health`

## Production build

```bash
cd PurrCare/frontend && npm run build
```

Serve the `frontend/dist` folder with any static host and run the backend separately, or configure your host to proxy `/api` to the Node server.
